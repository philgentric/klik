package klik.look.my_i18n;

public class Chinese extends Language
{
    public Chinese()
    {
        super("zh","Chinese","chinese-CHINA");
    }
}
