package klik.look.my_i18n;

public class Japanese extends Language
{
    public Japanese()
    {
        super("jp","JP","japanese-JAPAN");
    }
}
