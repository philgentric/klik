package klik.look.my_i18n;

public class Korean extends Language
{
    public Korean()
    {
        super("ko","KR","korean-KOREA");
    }
}
