package klik.look.my_i18n;

public class German extends Language
{
    public German()
    {
        super("de","German","german-GERMANY");
    }
}
