package klik.look.my_i18n;

public class Italian extends Language
{
    public Italian()
    {
        super("it","Italian","italian-ITALY");
    }
}
