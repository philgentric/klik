package klik.look.my_i18n;

public class Spanish extends Language
{
    public Spanish()
    {
        super("sp","Spanish","spanish-SPAIN");
    }
}
