package klik.look.my_i18n;

public class English extends Language
{
    public English()
    {
        super("en","English","english-USA");
    }
}
