package klik.look.my_i18n;

public class French extends Language
{
    public French()
    {
        super("fr","French","français-FRANCE");
    }
}
